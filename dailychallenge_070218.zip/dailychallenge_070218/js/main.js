// Complete the method/function so that it converts dash/underscore delimited words into camel casing. The first word within the output should be capitalized only if the original word was capitalized.
//
// Test.assertEquals(toCamelCase(''), '', "An empty string was provided but not returned")
// Test.assertEquals(toCamelCase("the_stealth_warrior"), "theStealthWarrior", "toCamelCase('the_stealth_warrior') did not return correct value")
// Test.assertEquals(toCamelCase("The-Stealth-Warrior"), "TheStealthWarrior", "toCamelCase('The-Stealth-Warrior') did not return correct value")
// Test.assertEquals(toCamelCase("A-B-C"), "ABC", "toCamelCase('A-B-C') did not return correct value")

//If I had more time, create a condition for when a string already starts with a capital letter do not change it

function toCamelCase(str) {
  var camel = str.replace(/(?:^\w|[A-Z]|-\w|_\w)/g,
  function(letter, index) {
    return index === 0 && letter === letter.toLowercase  ?
        letter.toLowercase : letter.toUpperCase();
    } ).replace(/(-|_)/g, "");
  console.log(camel);
  return camel;
  }
