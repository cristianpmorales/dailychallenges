function spinWords(wordString){
  return wordString.split("").reverse().join("");
}


// Test Results:
// Expected: 'Hey wollef sroirraw', instead got: 'sroirraw wollef yeH'

// Test.assertEquals(spinWords("Hey fellow warriors"), "Hey wollef sroirraw");
