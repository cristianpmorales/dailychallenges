function doTest(a, n) {
  console.log("A = ", a);
  console.log("n = ", n);
  new Test.assertEquals(findOdd(a), n);
}

  new Test.describe('Example tests', function() {
  doTest([20,1,-1,2,-2,3,3,5,5,1,2,4,20,4,-1,-2,5], 5);
  doTest([1,1,2,-2,5,2,4,4,-1,-2,5], -1);
  doTest([20,1,1,2,2,3,3,5,5,4,20,4,5], 5);
  doTest([10], 10);
  doTest([1,1,1,1,1,1,10,1,1,1,1], 10);
  doTest([5,4,3,2,1,5,4,3,2,10,10], 1);
});


function findOdd(A) {
	//loop through the array
	for (i=0; i < A.length; i++){
		//count the array
		count = A[i]
		//make sure to save each index in the array
		othernumber = count
		if (othernumber % 2 ==1){
				A=othernumber
		//return the index that appears an odd number of times
		}
	return A;
	}
}
